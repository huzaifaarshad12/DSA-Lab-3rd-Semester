import pandas as pd

# Load the dataset
df = pd.read_csv(r'CD:\Documents\Semester3\DSA Lab\Lab3\New\disease_data.csv')  # Replace with the actual path to your file

# Display the first few rows of the dataset
print(df.head())
